<?php 
include('header.php')
?>

    <main>
        <div class="header-video">
            <div id="hero_video">
                <div class="shape_element one"></div>
                <div class="shape_element two"></div>
                <div class="opacity-mask d-flex align-items-center" data-opacity-mask="rgba(0, 0, 0, 0.6)">
                    <div class="container">
                        <div class="row justify-content-center text-center">
                            <div class="col-xl-7 col-lg-8 col-md-8">
                                <h1>Buy Or Sell Your Product </h1>
                            <p>world's most popular marketplaces</p>
                                <form method="post" action="grid-listing-filterscol.php">
                            
                                  <div class="row no-gutters custom-search-input">
                                        <div class="col-lg-10">
                                            <div class="form-group">
                                                <input class="form-control no_border_r" type="text" placeholder="What are you looking for?">
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <button class="btn_1 gradient" type="submit">Search</button>
                                        </div>
                                    </div>
                                 </div>
                                
                                <!-- /row -->
                               
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="wave hero"></div>
        </div>
        <!-- /header-video -->

        <div class="container margin_30_60">
            <div class="main_title center">
                <span><em></em></span>
                <h2>Popular Categories</h2>
                <p>Cum doctus civibus efficiantur in imperdiet deterruisset</p>
            </div>
            <!-- /main_title -->

            <div class="owl-carousel owl-theme categories_carousel">
                <div class="item_version_2">
                    <a href="grid-listing-filterscol.php">
                        <figure>
                            <span></span>
                            <img src="img/mobile1.jpg" data-src="img/mobile1.jpg" alt="" class="owl-lazy" width="350" height="450">
                            <div class="info">
                                <h3>Mobile </h3>
                                <small>Starting price $10</small>
                            </div>
                        </figure>
                    </a>
                </div>
                <div class="item_version_2">
                    <a href="grid-listing-filterscol.php">
                        <figure>
                            <span></span>
                            <img src="img/pc1.jpg" data-src="img/pc1.jpg" alt="" class="owl-lazy" width="350" height="450">
                            <div class="info">
                                <h3>PC</h3>
                                <small>Starting price $100</small>
                            </div>
                        </figure>
                    </a>
                </div>
                <div class="item_version_2">
                    <a href="grid-listing-filterscol.php">
                        <figure>
                            <span></span>
                            <img src="img/laptop.jpg" data-src="" alt="" class="owl-lazy" width="350" height="450">
                            <div class="info">
                                <h3>Laptop</h3>
                                <small>Starting price $200</small>
                            </div>
                        </figure>
                    </a>
                </div>
                <div class="item_version_2">
                    <a href="grid-listing-filterscol.php">
                        <figure>
                            <span></span>
                            <img src="img/frige.jpg" data-src="" alt="" class="owl-lazy" width="350" height="450">
                            <div class="info">
                                <h3>Refrigitor</h3>
                                <small>Starting price $300</small>
                            </div>
                        </figure>
                    </a>
                </div>
                <div class="item_version_2">
                    <a href="grid-listing-filterscol.php">
                        <figure>
                            <span></span>
                            <img src="img/electronic.jpg" data-src="" alt="" class="owl-lazy" width="350" height="450">
                            <div class="info">
                                <h3>Electronic</h3>
                                <small>Starting price $300</small>
                            </div>
                        </figure>
                    </a>
                </div>
                <div class="item_version_2">
                    <a href="grid-listing-filterscol.php">
                        <figure>
                            <span></span>
                            <img src="img/car.jpg" data-src="" alt="" class="owl-lazy" width="350" height="450">
                            <div class="info">
                                <h3>Car</h3>
                                <small>Starting price $500</small>
                            </div>
                        </figure>
                    </a>
                </div>
            </div>
            <!-- /carousel -->
        </div>
        <!-- /container -->

        <div class="bg_gray">
            <div class="container margin_60_40">
                <div class="main_title">
                    <span><em></em></span>
                    <h2>Top Rated Restaurants</h2>
                    <p>Cum doctus civibus efficiantur in imperdiet deterruisset.</p>
                    <a href="#0">View All &rarr;</a>
                </div>
                <div class="row add_bottom_25">
                    <div class="col-lg-6">
                        <div class="list_home">
                            <ul>
                                <li>
                                    <a href="detail-restaurant.php">
                                        <figure>
                                            <img src="img/dhaka.jpg" data-src="" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>9.5</strong></div>
                                        <em>Most Popular</em>
                                        <h3>Dhaka  </h3>
                                        <small></small>
                                        <ul>
                                            <li><span class="ribbon off">-20%</span></li>
                                            <li>Average price $10</li>
                                        </ul>
                                        
                                    </a>
                                </li>
                                <li>
                                    <a href="detail-restaurant.php">
                                        <figure>
                                            <img src="img/sylhet-700x431.jpg" data-src="" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>8.0</strong></div>
                                        <em>Traditional city </em>
                                        <h3>Sylhet </h3>
                                        <small></small>
                                        <ul>
                                            <li><span class="ribbon off">-20%</span></li>
                                            <li>Average price $10</li>
                                        </ul>
                                    </a>
                                </li>
                                <li>
                                    <a href="detail-restaurant.php">
                                        <figure>
                                            <img src="img/mymensinghnews-3-584x440.jpg" data-src="" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>9.0</strong></div>
                                        <em>We are now </em>
                                        <h3>Mymensinghnews</h3>
                                        <small>Order Your Fev. Food </small>
                                        <ul>
                                            <li><span class="ribbon off">-90%</span></li>
                                            <li>Average price $1</li>
                                        </ul>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="list_home">
                            <ul>
                                <li>
                                    <a href="detail-restaurant.php">
                                        <figure>
                                            <img src="img/tajhat-palace-front-right.jpg" data-src="" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>9.5</strong></div>
                                        <em>Your Fev. City </em>
                                        <h3>Rangpur</h3>
                                        <small>Order Now </small>
                                        <ul>
                                            <li><span class="ribbon off">-30%</span></li>
                                            <li>Average price $5</li>
                                        </ul>
                                    </a>
                                </li>
                                <li>
                                    <a href="detail-restaurant.php">
                                        <figure>
                                            <img src="img/resize.jpg" data-src="" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>8.0</strong></div>
                                        <em>We are Now port city</em>
                                        <h3>Chattogram</h3>
                                        <small>Order Your fev food </small>
                                        <ul>
                                            <li><span class="ribbon off">-85%</span></li>
                                            <li>Average price $3</li>
                                        </ul>
                                    </a>
                                </li>
                                <li>
                                    <a href="detail-restaurant.php">
                                        <figure>
                                            <img src="img/rajshahi_road_side_tree.jpg" data-src="" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>8.5</strong></div>
                                        <em>We are now Your Fev. City </em>
                                        <h3>Rajshahi </h3>
                                        <small>Order and get free offer </small>
                                        <ul>
                                            <li><span class="ribbon off">-45%</span></li>
                                            <li>Average price $5</li>
                                        </ul>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /row -->
                
                    <!-- /wrapper -->
                </div>
                <!-- /banner -->
            </div>
        </div>
        <!-- /bg_gray -->

        <div class="shape_element_2">
            <div class="container margin_60_0">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="box_how">
                                    <figure><img src="img/order.png" data-src="" alt="" width="150" height="167" class="lazy"></figure>
                                    <h3>Easly Order</h3>
                                    <p>Faucibus ante, in porttitor tellus blandit et. Phasellus tincidunt metus lectus sollicitudin.</p>
                                </div>
                                <div class="box_how">
                                    <figure><img src="img/lazy-placeholder-100-100-white.png" data-src="img/how_2.svg" alt="" width="130" height="145" class="lazy"></figure>
                                    <h3>Quick Delivery</h3>
                                    <p>Maecenas pulvinar, risus in facilisis dignissim, quam nisi hendrerit nulla, id vestibulum.</p>
                                </div>
                            </div>
                            <div class="col-lg-6 align-self-center">
                                <div class="box_how">
                                    <figure><img src="img/save.jpg" data-src="" alt="" width="150" height="132" class="lazy"></figure>
                                    <h3>Save Your Time</h3>
                                    <p>Morbi convallis bibendum urna ut viverra. Maecenas quis consequat libero, a feugiat eros.</p>
                                </div>
                            </div>
                        </div>
                        <p class="text-center mt-3 d-block d-lg-none"><a href="#0" class="btn_1 medium gradient pulse_bt mt-2">Register Now!</a></p>
                    </div>
                    <div class="col-lg-5 offset-lg-1 align-self-center">
                        <div class="intro_txt">
                            <div class="main_title">
                                <span><em></em></span>
                                <h2>Start Ordering Now</h2>
                            </div>
                            <p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet libero id nisi euismod, sed porta est consectetur deserunt.</p>
                            <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                            <p><a href="#" class="btn_1 medium gradient pulse_bt mt-2">Register</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /shape_element_2 -->

    </main>
    <!-- /main -->

   <?php include('footer.php')?>