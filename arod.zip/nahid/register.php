<?php include('header.php')?>


<form action="functions/ahthcode.php" method="POST">

<div class="container" style="margin-left:250px ;">

   <div class="row justify-content-center" style="margin-top: 200px;" >

   <div class="col-md-8">

   <body id="register_bg">
   <div class="access_social">
					<a href="#0" class="social_bt facebook">Register with Facebook</a>
					<a href="#0" class="social_bt google">Register with Google</a>
				</div>
   <div class="form-group">
    <label for="exampleInputEmail1" class="form-label">Name</label>
    <input type="text" class="form-control" placeholder="enter your name">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" class="form-label">Phone</label>
    <input type="number" class="form-control" placeholder="enter your phone number">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" class="form-control" placeholder="enter your email ">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="enter your password">
  </div>
  <div class="form-group">
    <label  class="form-label">Confirm Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="confirm password">
  </div>
  <button type="submit" class="btn_1 gradient full-width" name="registor_btn">Register</button>
		
				<div class="text-center mt-2"><small>Already have an acccount? <strong><a href="login.php">Sign In</a></strong></small></div>
			</form>
		
		</aside>
	</div>

   </div>
   </div>

</div>

</form>

	<?php include('footer.php')?>











	<form>
  <div class="form-group">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1">
  </div>
  <button type="submit" class="btn_1 gradient full-width">Submit</button>
</form>