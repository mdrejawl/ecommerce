<?php
$host= "localhost";
$username= "root";
$password = "";
$database = "foodfrancy";

$con = mysqli_connect($host,$username,$password,$database);

if(!$con){
   die("Connection error: " . mysqli_connect_errno());
}
 
else{
   echo"Connected Suscessfully";
}

?>