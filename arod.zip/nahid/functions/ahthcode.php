<?php

session_start();
include('../config/dibicon.php');

if(isset($_POST['registor_btn']))
{
  $name = mysqil_real_escape_string($con,$_POST['name']);
  $phone = mysqil_real_escape_string($con,$_POST['phone']);
  $email = mysqil_real_escape_string($con,$_POST['email']);
  $password = mysqil_real_escape_string($con,$_POST['password']);
  $cpassword = mysqil_real_escape_string($con,$_POST['cpassword']);
 // email check যদি আগে থেকে ইমেইল ডটাবেচ এ থেকে থাকে তাহলে সেটা দেখাবে 
 $check_email_query = "SELECT email FROM users WHERE email='$email' ";
 $check_email_query_run = mysqli_query($con,$check_email_query);
if(mysqli_num_rows($check_email_query_run) >0 )
{
   $_SESSION['message'] = "Email alredy register";
   header('Loacation: register.php');
}
  
else{



  if($password == $cpassword)
  {

 // insert user data
 $insert_query = "INSERT INTO user (name,email,phone,password) VALUES ('$name','$email','$phone','$password')";
 $insert_query_run = mysqli_query($con, $insert_query );

 if( $insert_query_run)
{

   $_SESSION['message'] = "Regestered Successfully";
   header('Loacation: login.php');
}

else
{
   $_SESSION['message'] = "Somthing wrong";
   header('Loacation: register.php');
}


  }
  else
  {
    $_SESSION['message'] = "Password do not match";
    header('Location: register.php');
  }




}

else if(isset($_POST['login.php']))
{
   $email = mysqli_real_escape_string($con,$_POST['email']);
   $password = mysqli_real_escape_string($con,$_POST['password']);
   
    $login_query = "SELECT * FROM users WHERE email='$email' AND password = '$password' ";
    $login_query_run = mysqli_query($con,$login_query);

    if(mysqli_num_rows($login_query_run) > 0)
    {
        $_SESSION['auth'] = true;
        $userdata= mysqli_fetch_array($login_query_run );
      $username = $userdata['name'];
      $$useremail = $userdata['email'];
      

        $_SESSION['auth_user'] = [
        
         'name' =>$username,
         'email' =>$useremail

        ];

        $_SESSION['message'] = "Login Successfully";
        header('Location: ../index.php');
}
      
      }
else
{
   $_SESSION['message'] = "Invalid Credentils";
   header('Location: ../login.php');
}
}



?>