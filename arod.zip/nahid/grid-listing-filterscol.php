<?php include('header.php') ?>
	<!-- /header -->
	
	<main style="margin-top:100px ;">
	    <div class="page_header element_to_stick">
	        <div class="container">
	            <div class="row">
	                <div class="col-xl-8 col-lg-7 col-md-7 d-none d-md-block">
	                    <h1>All Bangladesh delivery 55 Taka </h1>
	                    <a href="#0">Change address</a>
	                </div>
	                <div class="col-xl-4 col-lg-5 col-md-5">
	                    <div class="search_bar_list">
	                        <input type="text" class="form-control" placeholder="Dishes, restaurants or cuisines">
	                        <button type="submit"><i class="icon_search"></i></button>
	                    </div>
	                </div>
	            </div>
	            <!-- /row -->
	        </div>
	    </div>
	    <!-- /page_header -->
	

	    <div class="collapse filters_2" id="collapseFilters">
	        <div class="container margin_30_20">
	            <div class="row">
	                <div class="col-md-4">
	                    <div class="filter_type">
	                        <h6>Categories</h6>
	                        <ul>
	                            <li>
	                                <label class="container_check">Pizza - Italian <small>12</small>
	                                    <input type="checkbox">
	                                    <span class="checkmark"></span>
	                                </label>
	                            </li>
	                            <li>
	                                <label class="container_check">Japanese - Sushi <small>24</small>
	                                    <input type="checkbox">
	                                    <span class="checkmark"></span>
	                                </label>
	                            </li>
	                            <li>
	                                <label class="container_check">Burghers <small>23</small>
	                                    <input type="checkbox">
	                                    <span class="checkmark"></span>
	                                </label>
	                            </li>
	                            <li>
	                                <label class="container_check">Vegetarian <small>11</small>
	                                    <input type="checkbox">
	                                    <span class="checkmark"></span>
	                                </label>
	                            </li>
	                        </ul>
	                    </div>
	                </div>
	                <div class="col-md-4">
	                    <div class="filter_type">
	                        <h6>Rating</h6>
	                        <ul>
	                            <li>
	                                <label class="container_check">Superb 9+ <small>06</small>
	                                    <input type="checkbox">
	                                    <span class="checkmark"></span>
	                                </label>
	                            </li>
	                            <li>
	                                <label class="container_check">Very Good 8+ <small>12</small>
	                                    <input type="checkbox">
	                                    <span class="checkmark"></span>
	                                </label>
	                            </li>
	                            <li>
	                                <label class="container_check">Good 7+ <small>17</small>
	                                    <input type="checkbox">
	                                    <span class="checkmark"></span>
	                                </label>
	                            </li>
	                            <li>
	                                <label class="container_check">Pleasant 6+ <small>43</small>
	                                    <input type="checkbox">
	                                    <span class="checkmark"></span>
	                                </label>
	                            </li>
	                        </ul>
	                    </div>
	                </div>
	                <div class="col-md-4">
	                    <div class="filter_type">
	                        <h6>Distance</h6>
	                        <div class="distance"> Radius around selected destination <span></span> km</div>
	                        <div class="mb-3
	                        "><input type="range" min="10" max="100" step="10" value="30" data-orientation="horizontal"></div>
	                    </div>
	                </div>
	            </div>
	            <!-- /row -->
	        </div>
	    </div>
	    <!-- /filters -->
	    <div class="container margin_30_20">

	        <div class="promo mb_30">
	            <h3>Free Delivery for your first 14 days!</h3>
	            <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.</p>
	            <i class="icon-food_icon_delivery"></i>
	        </div>
	        <!-- /promo -->

	        <div class="row isotope-wrapper">
	            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 isotope-item delivery">
	                <div class="strip">
	                    <figure>
	                        <span class="ribbon off">15% off</span>
	                        <img src="img/samsung.jpg" data-src="" class="img-fluid lazy" alt="">
	                        <a href="detail-restaurant.php" class="strip_info">
	                            <small>Mobile </small>
	                            <div class="item_title">
	                                <h3>Samsung </h3>
	                                <small>Lorem ipsum dolor sit amet.</small>
	                            </div>
	                        </a>
	                    </figure>
	                    <ul>
	                        <li><span class="take yes">Takeaway</span> <span class="deliv yes">Delivery</span></li>
	                        <li>
	                            <div class="score"><strong>8.9</strong></div>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	            <!-- /strip grid -->
	            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 isotope-item delivery">
	                <div class="strip">
	                    <figure>
	                        <img src="img/appo.jpg" data-src="" class="img-fluid lazy" alt="">
	                        <a href="detail-restaurant.php" class="strip_info">
	                            <small>Mobile </small>
	                            <div class="item_title">
	                                <h3>Appo</h3>
	                                <small>Lorem ipsum dolor sit amet.</small>
	                            </div>
	                        </a>
	                    </figure>
	                    <ul>
	                        <li><span class="take no">Takeaway</span> <span class="deliv yes">Delivery</span></li>
	                        <li>
	                            <div class="score"><strong>9.5</strong></div>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	            <!-- /strip grid -->
	            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 isotope-item takeaway">
	                <div class="strip">
	                    <figure>
	                        <span class="ribbon off">15% off</span>
	                        <img src="img/apple.jpg" data-src="" class="img-fluid lazy" alt="">
	                        <a href="detail-restaurant.php" class="strip_info">
	                            <small>Mobile </small>
	                            <div class="item_title">
	                                <h3>I Phone </h3>
	                                <small>Lorem ipsum dolor sit,</small>
	                            </div>
	                        </a>
	                    </figure>
	                    <ul>
	                        <li><span class="take yes">Takeaway</span> <span class="deliv no">Delivery</span></li>
	                        <li>
	                            <div class="score"><strong>7.5</strong></div>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	            <!-- /strip grid -->
	            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 isotope-item takeaway">
	                <div class="strip">
	                    <figure>
	                        <img src="img/motola.jpg" data-src="" class="img-fluid lazy" alt="">
	                        <a href="detail-restaurant.html" class="strip_info">
	                            <small>Mobile </small>
	                            <div class="item_title">
	                                <h3>Motola </h3>
	                                <small>Lorem ipsum dolor sit amet.</small>
	                            </div>
	                        </a>
	                    </figure>
	                    <ul>
	                        <li><span class="take">Takeaway</span> <span class="deliv no">Delivery</span></li>
	                        <li>
	                            <div class="score"><strong>9.5</strong></div>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	            <!-- /strip grid -->
	            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 isotope-item takeaway">
	                <div class="strip">
	                    <figure>
	                        <img src="img/symphony.png" data-src="" class="img-fluid lazy" alt="">
	                        <a href="detail-restaurant.html" class="strip_info">
	                            <small>Mobile </small>
	                            <div class="item_title">
	                                <h3>Symphony</h3>
	                                <small>Lorem ipsum dolor sit amet.</small>
	                            </div>
	                        </a>
	                    </figure>
	                    <ul>
	                        <li><span class="take yes">Takeaway</span> <span class="deliv no">Delivery</span></li>
	                        <li>
	                            <div class="score"><strong>7.0</strong></div>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	            <!-- /strip grid -->
	            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 isotope-item delivery">
	                <div class="strip">
	                    <figure>
	                        <img src="img/wlaton.jpg" data-src="" class="img-fluid lazy" alt="">
	                        <a href="detail-restaurant.html" class="strip_info">
	                            <small>Phone</small>
	                            <div class="item_title">
	                                <h3>Walton </h3>
	                                <small>Lorem ipsum dolor sit amet.</small>
	                            </div>
	                        </a>
	                    </figure>
	                    <ul>
	                        <li><span class="take no">Takeaway</span> <span class="deliv yes">Delivery</span></li>
	                        <li>
	                            <div class="score"><strong>8.9</strong></div>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	            <!-- /strip grid -->
	            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 isotope-item delivery">
	                <div class="strip">
	                    <figure>
	                        <img src="img/lg.jpg" data-src="" class="img-fluid lazy" alt="">
	                        <a href="detail-restaurant.html" class="strip_info">
	                            <small>Phone</small>
	                            <div class="item_title">
	                                <h3>LG </h3>
	                                <small>27 Old Gloucester St</small>
	                            </div>
	                        </a>
	                    </figure>
	                    <ul>
	                        <li><span class="take no">Takeaway</span> <span class="deliv yes">Delivery</span></li>
	                        <li>
	                            <div class="score"><strong>8.9</strong></div>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	            <!-- /strip grid -->
	            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 isotope-item takeaway">
	                <div class="strip">
	                    <figure>
	                        <img src="img/itel.jpg" data-src="" class="img-fluid lazy" alt="">
	                        <a href="detail-restaurant.html" class="strip_info">
	                            <small>Phone</small>
	                            <div class="item_title">
	                                <h3>Itel</h3>
	                                <small>Lorem ipsum dolor sit amet.</small>
	                            </div>
	                        </a>
	                    </figure>
	                    <ul>
	                        <li><span class="take yes">Takeaway</span> <span class="deliv no">Delivery</span></li>
	                        <li>
	                            <div class="score"><strong>8.9</strong></div>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	            <br><br><br>
				<!-- /strip grid -->
	            
	            
				<!-- /strip grid -->
	            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-6 isotope-item delivery takeaway">
	                <div class="strip">
	                    <figure>
	                        <img src="img/xiaomi.png" data-src="" class="img-fluid lazy" alt="">
	                        <a href="detail-restaurant.html" class="strip_info">
	                            <small> Phone </small>
	                            <div class="item_title">
	                                <h3>Xiaomi </h3>
	                                <small>135 Newtownards Road</small>
	                            </div>
	                        </a>
	                    </figure>
	                    <ul>
	                        <li><span class="take yes">Takeaway</span> <span class="deliv yes">Delivery</span></li>
	                        <li>
	                            <div class="score"><strong>8.9</strong></div>
	                        </li>
	                    </ul>
	                </div>
	            </div>
	            <!-- /strip grid -->
	        </div>
	        <!-- /strip row -->
	        <div class="pagination_fg">
	            <a href="#">&laquo;</a>
	            <a href="#" class="active">1</a>
	            <a href="#">2</a>
	            <a href="#">3</a>
	            <a href="#">4</a>
	            <a href="#">5</a>
	            <a href="#">&raquo;</a>
	        </div>
	    </div>
	    <!-- /container -->
	</main>
	<!-- /main -->

	<?php include('footer.php')?>