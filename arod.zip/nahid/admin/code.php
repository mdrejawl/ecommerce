<?php 

session_start();
include('../config/dibicon.php');
include('../functions/myfuncations.php');


if(isset($_POST['add-catagory-btn']))
{
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $description = $_POST['description'];
    $meta_title = $_POST['meta_title'];
    $short_description = $_POST['short_description'];
    $crated_ad = isset($_POST['crated_ad']) ? '1':'0';
    $popular = isset($_POST['popular']) ? '1':'0';


    $img = $_FILES['img']['name'];

    $path = "../uploads";

    $img_ext = pathinfo($img, PATHINFO_EXTENSION);
    $filename = time().'.'.$img_ext;

   
    $cate_query = "INSERT INTO catagories 
    (name,slug,description, meta_title, short_description,crated_ad, popular)
    VALUES ('name','slug','description', 'meta_title', 'short_description','crated_ad', 'popular') ;

    $cate_query_run = mysqli_query($con, $cate_query);

    if( $cate_query_run)
{
 move_uploaded_file($_FILES['image'] ['tmp_name'], $path.'/'.$filename);
 redirect('addcatagory.php', 'Catagory added')
}
    
else{
 redirect('addcatagory.php', 'Somthing wrong');

}

}

else if( isset($_POST['add-product-btn']))
{
    $catagory_id = $_POST['catagory_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $meta_title = $_POST['meta_title'];
    $description = $_POST['description'];
    $short_description = $_POST['short_description'];
    $orginial_price = $_POST['orginial_price'];
    $selling_price = $_POST['selling_price'];
    $meta_discription = $_POST['meta_discription'];
    $meta_keywords = $_POST['meta_keywords'];
    $qty = $_POST['qty'];
    $status = isset($_POST['status']) ? '1':'0';
    $trending = isset($_POST['trending']) ? '1':'0';


    $img = $_FILES['img']['name'];

    $path = "../uploads";

    $img_ext = pathinfo($img, PATHINFO_EXTENSION);
    $filename = time().'.'.$img_ext;

    $product_query = "INSERT INTO products (catagory_id,name,)"
}

?>