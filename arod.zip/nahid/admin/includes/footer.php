<footer class="footer pt-5">
      <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
          
          <div class="col-lg-12">
    
                <a href="#" class="nav-link pe-0 text-muted" target="_blank">Developer</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  </div>
  </main>

  <script src="../assets/js/core/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/perfect-scrollbar.min.js"></script>
  <script src="../assets/js/smooth-scrollbar.min.js"></script>

  </body>

</html>