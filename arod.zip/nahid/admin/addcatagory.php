<?php include('includes/header.php');?>


<div class="container">

 <div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4>Add Catagory </h4>
            </div>
            <div class="card-body">
                <form action="code.php" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                    <label for="">Name</label>
                     <input type="text" name="name" placeholder="Catagory name" class="form-control">
                    </div>
                    <div class="col-md-6">
                    <label for="">Slug</label>
                     <input  type="text" name="slug" class="form-control" placeholder="slug">
                    </div>

                    <div class="col-md-12">
                    <label for="">Discription</label>
                     <input  type="text" name="description" class="form-control" placeholder=" Enter Your description">
                    </div>

                    
                </div>


                <div class="row">
                    <div class="col-md-6">
                    <label for="">Meta title</label>
                     <input type="text" name="meta_title" placeholder="meta title" class="form-control">
                    </div>
                    <div class="col-md-6">
                    <label for="">short description</label>
                     <input  type="text" name="short_description" class="form-control" placeholder="short description">
                    </div>

                    <div class="col-md-6">
                    <label for="">Upload Image</label>
                     <input  type="file" name="img" class="form-control">
                    </div>
                    <br>

                    <div class="col-md-8">
                    <label for="">crated ad</label>
                     <input  type="checkbox" name="crated_ad">
                    </div>
                    <div class="col-md-4">
                    <label for="">Popular</label>
                     <input  type="checkbox" name="popular">
                    </div>

                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary" name="add-catagory-btn"> Add a new Catagory</button>
                    </div>

                </div>

                </form>


            </div>
        </div>
    </div>
 </div>
</div>



<?php include('includes/footer.php');?>