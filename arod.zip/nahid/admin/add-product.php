<?php include('includes/header.php');?>


<div class="container">

 <div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4>Add Product</h4>
            </div>
            <div class="card-body">
                <form action="code.php" method="POST" enctype="multipart/form-data">
                <div class="row">
                <div class="col-md-6">
                    <label for="">Select Catagory </label>
                    <select class="form-control" name="catagory_id" aria-label="">
                        <option selected>Pizza</option>
                       <option value="1">সিঙ্গারা </option>
                         <option value="2">বিরিয়ানি</option>
                            <option value="3"> চাইনিস</option>
                                </select>

                    </div>
                    <div class="col-md-6">
                    <label for="">Name</label>
                     <input type="text" name="name" placeholder="Product name" class="form-control mb-2">
                    </div>
                    <div class="col-md-6">
                    <label for="">Slug</label>
                     <input  type="text" name="slug" class="form-control mb-2" placeholder="slug">
                    </div>

                    <div class="row">
                    <div class="col-md-6">
                    <label for="">Meta Title </label>
                     <input type="text" name="meta_title" placeholder="Meta Title" class="form-control mb-2">
                    </div>

                    <div class="col-md-12">
                    <label for="">Discription</label>
                    <textarea rows="3" type="text" name="description" class="form-control mb-2" placeholder=" description"> </textarea>
                    </div>

                    <div class="col-md-12">
                    <label for="">short description</label>
                     <textarea rows="3" type="text" name="short_description" class="form-control mb-2" placeholder="short description"> </textarea>
                    </div>
                    <div class="col-md-6">
                    <label for="">Orginial Price </label>
                     <input type="text" name="orginial_price" placeholder="" class="form-control mb-2">
                    </div>
                    <div class="col-md-6">
                    <label for="">Selling Price </label>
                     <input  type="text" name="selling_price" class="form-control mb-2" placeholder="">
                    </div>
                    <br>
                    <div class="col-md-6">
                    <label for="">Upload Image</label> <br>
                     <input  type="file" name="img" class="">

                     <div class="col-md-12">
                    <label for="">Meta discription</label>
                    <textarea rows="3" type="text" name="meta_discription" class="form-control mb-2" placeholder=" description"> </textarea>
                    </div>

                     
                   <div class="row">
                    <div class="">
                    <label for="">Meta keywords</label>
                     <input type="text" name="meta_keywords" placeholder="Meta keywords" class="form-control mb-2">
                    </div>

                    <div class="col-md-3">
                    <label for="">Quentity </label>
                     <input  type="number" name="qty" class="form-control mb-2" placeholder="Quentity">
                    </div>
                
                    </div>
                    <br>
                    <div class="col-md-6">
                    <label for="">Status</label>
                     <input  type="checkbox" name="status">
                    </div>
                    <div class="col-md-3">
                    <label for="">Trending</label>
                     <input  type="checkbox" name="trending">
                    </div>
                


                    
                </div>


                   

                    

                   
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary" name="add-product-btn">Update Product </button>
                    </div>

                </div>

                </form>


            </div>
        </div>
    </div>
 </div>
</div>



<?php include('includes/footer.php');?>